A8, source baseline e369c324, single import relocation in certus_strat_ui_state.
Raw and fixed-hash-seed namespace snapshots, before/after entry import and facade surfaces,
original-source smoother replay, source copies and all validation logs are retained.
Log paths are normalized to <WORKTREE>, <PYTHON> and <USER_HOME>; originals remain in scratch.
The first unit attempt failed on the architecture line-count ratchet; the successful
rerun uses its single reduced ceiling (1725 -> 1722). See validation_state.json.
For reproduction, place snapshot_entry_surfaces_A8.py under scratch/ of the worktree;
run one entry at a time with QT_QPA_PLATFORM=offscreen and PYTHONHASHSEED=0.
The helper waits for actual background JIT warmup; it does not run the GUI event loop.
Namespace tool: python scripts/lint_ns_snapshot.py <output.json> certus.ui.certus_strat_ui_state.
Use the original source and corrected source in separate sequential snapshots.
No numerical kernel or scientific default was modified.
