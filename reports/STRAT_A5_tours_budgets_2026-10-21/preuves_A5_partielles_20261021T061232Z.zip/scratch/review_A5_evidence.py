"""Unexecuted A5 readout draft; use only after the sequential controller exits."""

import collections
import hashlib
import json
import math
import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FOLDER = ROOT / "reports/STRAT_A5_tours_budgets_2026-10-21"
sys.path.insert(0, str(ROOT / "scripts"))
from resumer_artefact_sonde import SEUIL_PLANTAGE, paquets, resumer, seel


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main():
    state = read(FOLDER / "etat.json")
    assert state["status"] != "running", "Wait for the A5 chain to end"
    command = "@(Get-CimInstance Win32_Process -Filter \"name = 'python.exe'\" | Select-Object -ExpandProperty ProcessId) | ConvertTo-Json -Compress"
    pids = json.loads(subprocess.check_output(["powershell", "-NoProfile", "-Command", command], text=True) or "[]")
    assert set([pids] if isinstance(pids, int) else pids) <= {os.getpid()}, "Another Python is active"
    protocol = read(FOLDER / "protocole.json")
    output = {"measurement_head": state["head"], "controller_status": state["status"], "attempts": [], "missing_cases": []}
    for case, _overrides, rounds, stop, budget in protocol["cases"]:
        attempts = [record for record in state["attempts"] if record["case"] == case]
        if not any(record.get("measured") for record in attempts):
            output["missing_cases"].append(case)
        for record in attempts:
            slot = (ROOT / record["slot"]).resolve()
            artifact = (ROOT / record["artifact"]).resolve()
            assert slot.is_relative_to(FOLDER) and artifact.is_relative_to(ROOT / "reports")
            row = {"case": case, "attempt": record["attempt"], "measured": record.get("measured", False),
                   "wall_s": record.get("wall_s"), "exit_code": record.get("exit_code"), "checks": {}}
            raw = slot / "raw.log"
            if record.get("raw_sha256"):
                assert sha(raw) == record["raw_sha256"]
            row["raw_sha256"] = sha(raw) if raw.exists() else None
            if not record.get("measured"):
                output["attempts"].append(row)
                continue
            assert record["exit_code"] == 0
            assert sha(artifact) == record["artifact_sha256"]
            row["artifact_sha256"] = sha(artifact)
            payload = read(artifact)
            assert payload["verdict"] == "OK"
            row["probe_provenance"] = payload.get("provenance")
            audit = read(slot / "params_effectifs.json")
            expected = {"elite_rounds": rounds, "elite_stop_on_no_gain": stop, "elite_rate_max_candidates": budget}
            assert audit["worker_boundary"] and audit["resolved_elite"] and audit["generated_elite"]
            assert all(item["effective_elite"] == expected and item["effective_consensus_seeds"] == [41, 42, 43]
                       for item in audit["worker_boundary"])
            assert all(item["rounds"] == rounds and item["stop_on_no_gain"] == stop for item in audit["resolved_elite"])
            assert all(item["budget_received"] == budget for item in audit["generated_elite"])
            row["checks"]["effective_parameters"] = expected
            row["internal_run_counts"] = dict(collections.Counter(item["robustness_num_runs"] for item in audit["resolved_elite"]))
            row["generator_calls"] = len(audit["generated_elite"])
            text = raw.read_text(encoding="utf-8", errors="replace")
            observed = re.findall(r"\[ELITE\] Round (\d+)/(\d+): generated=(\d+) parents=(\d+)", text)
            assert len(observed) == row["generator_calls"]
            assert all(int(total) == rounds for _current, total, _generated, _parents in observed)
            row["generated_rounds_histogram"] = dict(collections.Counter(int(item[0]) for item in observed))
            row["maximum_generated_round_observed"] = max((int(item[0]) for item in observed), default=0)
            row["round_scope"] = "All ELITE calls, including preliminary screening and final evaluation; not a single loop"
            plans = payload.get("strategies", [])
            healthy = [plan for plan in plans if not plan.get("crash_eliminated", False)
                       and float(plan.get("crash_rate", 1.0)) < SEUIL_PLANTAGE]
            eligible = []
            for plan in healthy:
                meta = plan.get("robustness_consensus_meta") or {}
                score = plan.get("robustness_score_consensus")
                if (meta.get("seeds") == [41, 42, 43] and meta.get("mode") == "mean_std" and meta.get("n_samples") == 3
                        and score is not None and math.isfinite(float(score)) and float(score) > 0):
                    eligible.append(plan)
            best = min(eligible, key=lambda plan: float(plan["robustness_score_consensus"]), default=None)
            primary = None if best is None else seel(float(best["robustness_score_consensus"]))
            assert record.get("primary_seel_nm") == primary
            assert record["readout_valid"] == (bool(eligible) or not healthy)
            row.update(population_returned=len(plans), fallback_marked=sum(bool(plan.get("crash_eliminated")) for plan in plans),
                       deposable_unflagged=len(healthy), homogeneous_eligible=len(eligible),
                       primary_seel_nm=primary, best_primary_plan=best,
                       primary_rate_packets=None if best is None else len(paquets(best.get("rate_layers"))),
                       readout_valid=record["readout_valid"], existing_project_summary=resumer(payload))
            output["attempts"].append(row)
    target = FOLDER / "revue_mesures.json"
    with target.open("x", encoding="utf-8") as stream:
        json.dump(output, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    print("A5_REVIEW=" + target.relative_to(ROOT).as_posix())
    print("MISSING=" + ",".join(output["missing_cases"]))


if __name__ == "__main__":
    main()
