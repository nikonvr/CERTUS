A5 evidence snapshot 20261021T061232Z; all five cases complete: False.
Inspect the attempts, measured and readout_valid fields; missing cases stay missing.
Failures, negative results and original probe artifacts are preserved.
The frozen protocol's homogeneous three-sample consensus criterion is distinct from the historical minimum.
Research scores on a common bank are not an independent confirmation of fixed plans.
Text paths are normalized; both original and archived SHA-256 hashes are retained.
Markdown files are snapshots; the final report also records the archive hash.
