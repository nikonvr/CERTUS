"""Archive A5 only after process exit; retain failures and both text hashes."""

import argparse
import hashlib
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
FOLDER = ROOT / "reports/STRAT_A5_tours_budgets_2026-10-21"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def normalize(data):
    content = data.decode("utf-8")
    for prefix, marker in ((ROOT, "<WORKTREE>"), (Path.home(), "<USER_HOME>")):
        for spelling in (str(prefix), str(prefix).replace("\\", "\\\\"), prefix.as_posix()):
            content = content.replace(spelling, marker)
    for spelling in ("C:\\Python314", "C:\\\\Python314", "C:/Python314"):
        content = content.replace(spelling, "<PYTHON>")
    result = content.encode("utf-8")
    assert b"C:\\Users\\" not in result and b"C:/Users/" not in result
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--allow-incomplete", action="store_true")
    args = parser.parse_args()
    state = json.loads((FOLDER / "etat.json").read_text(encoding="utf-8-sig"))
    assert state["status"] != "running", "Wait for the active A5 chain"
    complete = state["status"] == "complete"
    assert complete or args.allow_incomplete, "Explicitly label an incomplete archive"
    query = "@(Get-CimInstance Win32_Process -Filter \"name = 'python.exe'\" | Select-Object -ExpandProperty ProcessId) | ConvertTo-Json -Compress"
    pids = json.loads(subprocess.check_output(["powershell", "-NoProfile", "-Command", query], text=True) or "[]")
    if isinstance(pids, int):
        pids = [pids]
    assert set(pids) <= {os.getpid()}, "Another Python process is active; no compression during a measure"
    paths = {path for path in FOLDER.rglob("*") if path.is_file() and path.suffix not in {".zip", ".incomplete"}}
    for attempt in state["attempts"]:
        slot = (ROOT / attempt["slot"]).resolve()
        artifact = (ROOT / attempt["artifact"]).resolve()
        assert slot.is_relative_to(FOLDER) and artifact.is_relative_to(ROOT / "reports")
        for path, field in ((slot / "raw.log", "raw_sha256"), (artifact, "artifact_sha256")):
            if path.exists():
                paths.add(path)
                if attempt.get(field):
                    assert digest(path.read_bytes()) == attempt[field], (attempt["case"], field)
    for name in ("A5_tours_budgets_20261021.log", "A5_loaded_params_20261021.log", "A5_coherence.log", "A5_claude.log", "A5_docs.log", "A5_review_arret_20261021.log", "A5_tools_ruff_arret.log", "review_A5_evidence.py"):
        path = ROOT / "scratch" / name
        if path.is_file():
            paths.add(path)
    paths.add(Path(__file__).resolve())
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    target = FOLDER / f"preuves_A5_{'completes' if complete else 'partielles'}_{stamp}.zip"
    temporary = target.with_suffix(".zip.incomplete")
    assert not target.exists() and not temporary.exists()
    manifest = {}
    with ZipFile(temporary, "x", compression=ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(paths):
            original = path.read_bytes()
            data = original if path.suffix in {".npy", ".npz"} or path == Path(__file__).resolve() else normalize(original)
            name = path.relative_to(ROOT).as_posix()
            archive.writestr(name, data)
            manifest[name] = {"original_sha256": digest(original), "archived_sha256": digest(data), "original_bytes": len(original)}
        archive.writestr("sha256.json", json.dumps(manifest, indent=2) + "\n")
        archive.writestr("README.txt", (
            f"A5 evidence snapshot {stamp}; all five cases complete: {complete}.\n"
            "Inspect the attempts, measured and readout_valid fields; missing cases stay missing.\n"
            "Failures, negative results and original probe artifacts are preserved.\n"
            "The frozen protocol's homogeneous three-sample consensus criterion is distinct from the historical minimum.\n"
            "Research scores on a common bank are not an independent confirmation of fixed plans.\n"
            "Text paths are normalized; both original and archived SHA-256 hashes are retained.\n"
            "Markdown files are snapshots; the final report also records the archive hash.\n"
        ))
    with ZipFile(temporary) as archive:
        assert archive.testzip() is None
        for name, values in manifest.items():
            assert digest(archive.read(name)) == values["archived_sha256"], name
    temporary.rename(target)
    print(f"ARCHIVE={target.relative_to(ROOT).as_posix()} FILES={len(manifest) + 2} BYTES={target.stat().st_size}")
    print("SHA256=" + digest(target.read_bytes()))


if __name__ == "__main__":
    main()
