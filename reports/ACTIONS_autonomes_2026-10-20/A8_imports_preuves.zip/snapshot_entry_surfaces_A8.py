"""Record entry-module imports after the real background warmup and facade names."""

import argparse
import importlib
import json
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("entry")
    parser.add_argument("output")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root))
    importlib.import_module(args.entry)

    from certus.core.certus_core import CertusFacadeModule, _WarmupRegistry, start_jit_warmup

    start_jit_warmup()
    thread = _WarmupRegistry.thread
    if thread is None:
        raise RuntimeError("The background warmup did not start")
    thread.join(timeout=300)
    if thread.is_alive():
        raise TimeoutError("The background warmup is still running after 300 s")

    facades = {}
    for alias, module in sorted(list(sys.modules.items())):
        if not isinstance(module, CertusFacadeModule):
            continue
        candidates = set()
        pending = [module]
        visited = set()
        while pending:
            current = pending.pop()
            if id(current) in visited:
                continue
            visited.add(id(current))
            candidates.update(vars(current))
            if isinstance(current, CertusFacadeModule):
                pending.extend(vars(current).get("_submodules", ()))
        served = []
        for name in sorted(candidates):
            try:
                getattr(module, name)
            except AttributeError:
                continue
            served.append(name)
        facades[alias] = served

    payload = {
        "entry": args.entry,
        "warmup_thread_completed": True,
        "loaded_modules": sorted(sys.modules),
        "facade_names": facades,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, sort_keys=True, indent=1) + "\n", encoding="utf-8")
    print(f"{args.entry}: {len(payload['loaded_modules'])} modules, {len(facades)} facades, warmup completed")


if __name__ == "__main__":
    main()
