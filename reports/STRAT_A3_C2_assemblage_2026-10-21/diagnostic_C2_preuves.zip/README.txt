NO SCIENTIFIC C2 SCORE WAS PRODUCED BY THIS PROTOTYPE.
It was blocked before numerical execution after mismatched normalization domains were established.
The earlier assembled scores are retained as rejected readouts, not references.
Thickness arrays remain in the preceding complete A3 evidence archive; their hashes are in protocole.json.
Historical prototype versions are audit data and must not be executed.
