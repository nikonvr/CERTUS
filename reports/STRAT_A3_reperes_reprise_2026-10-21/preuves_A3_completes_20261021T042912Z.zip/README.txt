A3 evidence snapshot 20261021T042912Z; controller coverage complete: True.
Controller completion does not imply every interval or assembled partition was depositable.
Inspect the status, validity, measured flags, unassembled seeds, and absent scores.
The protocols are frozen preregistrations; the Markdown files are snapshots at packaging time.
conditions_et_limites.md records the static review of settings and export limits.
The report folder contains the final synthesis after examination of these outputs.
All attempted bench outputs and interval slots are retained, including failed/negative cases.
Text paths are normalized; original and archived hashes are both retained.
Thickness arrays are byte-identical copies. No draw is regenerated for this archive.
Official benchmark RESULT and whole-piece assembled P95 are distinct quantities.
These research runs are not an independent confirmation of fixed winning plans.
