The official 48-layer premium bench at 58ff57c5 failed after computation: RESULT=None.
Its process exit was 0; the A3 controller correctly rejected it and launched no next bench.
The one-line correction uses the final_results dictionary key instead of an attribute.
No numerical kernel, search parameter, seed, scientific default or winning plan is modified.
The real full-pipeline method is exercised with fake numerical stages and fake Qt threads,
but a genuine WorkerThreadResult.to_legacy_dict payload. The test fails on the original
AttributeError before the fix and passes for disabled, accepted and refused search after it.
All configured Ruff, oracle, unit, UI, other and document checks completed with exit 0.
See validation_state.json for commands and measured summaries; sources and their diff are included.
Log paths are normalized; sha256.json retains original and archived hashes.
Original raw logs and auto-generated HTML/Excel exports remain locally preserved.
No score printed before the failed final emission is claimed as a valid A3 reference.
